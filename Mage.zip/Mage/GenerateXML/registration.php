
<?php
//step 2
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    	'Mage_GenerateXML',
	__DIR__
);
?>