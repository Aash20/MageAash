<?php

namespace Mage\GenerateXML\Observer;
class ObserverXML implements \Magento\Framework\Event\ObserverInterface
{
    public function __construct(
    \Magento\Framework\Filesystem\Io\File $file,
    \Magento\Framework\Convert\ConvertArray $convertArray
    )
    {
        $this->file = $file;
        $this->convertArray = $convertArray;
    }
    public function createMyXmlFile($assocArray, $rootNodeName, $filename = 'file.xml',\Magento\Framework\Event\Observer $observer)
    {
        /* $myArray = array(
          'fruit' => 'apple',
          'vegetables' => array('vegetable_1' => 'carrot', 'vegetable_2' => 'tomato'),
          'meat' => 'none',
          'sweets' => 'chocolate');*/
          //fetching order data 
        $order = $observer->getEvent()->getOrder();     
        $billing = $order->getBillingAddress();
        $shipping = $order->getShippingAddress();
        $customer = $order->getCustomer();         
        $order_id = $order->getIncrementId();
        $customer_id = $order->getCustomerId(); 
        // to array
        $myArray =array(
           'Customer Name' =>  $customer,
           'Order Id' =>  $order_id,
           'Billing Address' =>  $billing,
           );
        // ConvertArray function assocToXml to create SimpleXMLElement
        $simpleXmlContents = $this->convertArray->assocToXml($assocArray,rootNodeName);
        // convert it to xml using asXML() function
        $content = $simpleXmlContents->asXML();
        $this->file->write($filename, $contents);
        $simpleXmlContents =  $this->convertArray->assocToXml($myArray, 'diner');
        //XML generation
        $this->file->write($myXmlFile,$simpleXmlContents->asXML());
    }
}

